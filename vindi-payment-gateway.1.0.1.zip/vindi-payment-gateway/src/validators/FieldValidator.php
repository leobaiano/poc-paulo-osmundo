<?php
/**
 * Vindi Validators
 *
 * Validates the fields that will be sent to the api.
 *
 * @since 1.0.0
 *
 * @return void
 */

class FieldValidator {

  public function customer() {



  }
}
